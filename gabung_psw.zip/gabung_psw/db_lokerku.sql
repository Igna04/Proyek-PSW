-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Bulan Mei 2022 pada 13.46
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_lokerku`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `benda`
--

CREATE TABLE `benda` (
  `idBenda` int(10) NOT NULL,
  `jenisBenda` char(20) NOT NULL,
  `waktuPenyimpanan` date NOT NULL,
  `waktuPengambilan` date NOT NULL,
  `nim` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `chatting`
--

CREATE TABLE `chatting` (
  `idChat` int(10) NOT NULL,
  `nim` varchar(10) NOT NULL,
  `idKeasramaan` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `keasramaan`
--

CREATE TABLE `keasramaan` (
  `idKeasramaan` int(10) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `namaKeasramaan` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan`
--

CREATE TABLE `laporan` (
  `noLaporan` int(10) NOT NULL,
  `idKeasramaan` int(10) NOT NULL,
  `idLoker` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `iduser` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`iduser`, `email`, `password`) VALUES
(1, 'doli123@gmail.com', '123456789');

-- --------------------------------------------------------

--
-- Struktur dari tabel `loker`
--

CREATE TABLE `loker` (
  `idLoker` int(10) NOT NULL,
  `noLoker` int(10) NOT NULL,
  `nim` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` varchar(10) NOT NULL,
  `namaMahasiswa` varchar(50) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `passLoker` int(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `namaMahasiswa`, `username`, `password`, `gender`, `passLoker`) VALUES
('11421036', 'Doli Rajagukguk', 'doli123', '123456789', 'pria', 12345);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tambahbarang`
--

CREATE TABLE `tambahbarang` (
  `idbarang` int(11) NOT NULL,
  `jenisbarang` varchar(50) NOT NULL,
  `waktupenyimpanan` date NOT NULL,
  `waktupengambilan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tambahbarang`
--

INSERT INTO `tambahbarang` (`idbarang`, `jenisbarang`, `waktupenyimpanan`, `waktupengambilan`) VALUES
(0, 'jam', '2022-05-16', '2022-05-17'),
(0, 'baju', '2022-05-26', '2022-05-21');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `benda`
--
ALTER TABLE `benda`
  ADD PRIMARY KEY (`idBenda`),
  ADD KEY `nim` (`nim`);

--
-- Indeks untuk tabel `chatting`
--
ALTER TABLE `chatting`
  ADD PRIMARY KEY (`idChat`),
  ADD KEY `nim` (`nim`),
  ADD KEY `idKeasramaan` (`idKeasramaan`);

--
-- Indeks untuk tabel `keasramaan`
--
ALTER TABLE `keasramaan`
  ADD PRIMARY KEY (`idKeasramaan`);

--
-- Indeks untuk tabel `laporan`
--
ALTER TABLE `laporan`
  ADD PRIMARY KEY (`noLaporan`),
  ADD KEY `idKeasramaan` (`idKeasramaan`),
  ADD KEY `idLoker` (`idLoker`);

--
-- Indeks untuk tabel `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`iduser`);

--
-- Indeks untuk tabel `loker`
--
ALTER TABLE `loker`
  ADD PRIMARY KEY (`idLoker`),
  ADD KEY `nim` (`nim`);

--
-- Indeks untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `benda`
--
ALTER TABLE `benda`
  ADD CONSTRAINT `benda_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`);

--
-- Ketidakleluasaan untuk tabel `chatting`
--
ALTER TABLE `chatting`
  ADD CONSTRAINT `chatting_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`),
  ADD CONSTRAINT `chatting_ibfk_2` FOREIGN KEY (`idKeasramaan`) REFERENCES `keasramaan` (`idKeasramaan`);

--
-- Ketidakleluasaan untuk tabel `laporan`
--
ALTER TABLE `laporan`
  ADD CONSTRAINT `laporan_ibfk_1` FOREIGN KEY (`idKeasramaan`) REFERENCES `keasramaan` (`idKeasramaan`),
  ADD CONSTRAINT `laporan_ibfk_2` FOREIGN KEY (`idLoker`) REFERENCES `loker` (`idLoker`);

--
-- Ketidakleluasaan untuk tabel `loker`
--
ALTER TABLE `loker`
  ADD CONSTRAINT `loker_ibfk_1` FOREIGN KEY (`nim`) REFERENCES `mahasiswa` (`nim`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
