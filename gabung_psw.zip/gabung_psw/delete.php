<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';
// Check that the contact ID exists
if (isset($_GET['nim'])) {
    // Select the record that is going to be deleted
    $stmt = $pdo->prepare('SELECT * FROM tambahmahasiswa WHERE nim = ?');
    $stmt->execute([$_GET['nim']]);
    $nim = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$nim) {
        exit('College doesn\'t exist with that NIM!');
    }
    // Make sure the user confirms beore deletion
    if (isset($_GET['confirm'])) {
        if ($_GET['confirm'] == 'yes') {
            // User clicked the "Yes" button, delete record
            $stmt = $pdo->prepare('DELETE FROM tambahmahasiswa WHERE nim = ?');
            $stmt->execute([$_GET['nim']]);
            $msg = 'You have deleted the College!';
        } else {
            // User clicked the "No" button, redirect them back to the read page
            header('Location: read.php');
            exit;
        }
    }
} else {
    //exit('No NIM specified!');
}
?>


<?=template_header('Delete')?>

<div class="content delete">
	<h2>Delete College<?=$nim['nim']?></h2>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php else: ?>
	<p>Are you sure you want to delete college<?=$nim['nim']?>?</p>
    <div class="yesno">
        <a href="delete.php?id=<?=$nim['nim']?>&confirm=yes">Yes</a>
        <a href="delete.php?id=<?=$nim['nim']?>&confirm=no">No</a>
    </div>
    <?php endif; ?>
</div>

<?=template_footer()?>