<?php
    session_start();
    //Membuat koneksi ke database
    $conn = mysqli_connect("localhost","root","","db_lokerku");
    
    //Menambah barang
    if(isset($_POST['addnewbarang'])){
        $jenisbarang = $_POST['jenisbarang'];
        $waktupenyimpanan = $_POST['waktupenyimpanan'];
        $waktupengambilan = $_POST['waktupengambilan'];

        $addtotable = mysqli_query($conn,"insert into tambahbarang (jenisbarang, waktupenyimpanan, waktupengambilan) values('$jenisbarang','$waktupenyimpanan','$waktupengambilan')");
        if($addtotable){
            header('location:mhs_loker.php');

        } else {
            echo 'Gagal';
            header('location:mhs_loker.php');
        }

    }


    //Hapus Barang
    if(isset($_POST['hapusbarang'])){
        $idb = $_POST['idb'];

        $hapus = mysqli_query($conn, "delete from tambahbarang where idbarang='$idb'");
        if($hapus){
            header('location:mhs_loker.php');

        } else {
            echo 'Gagal';
            header('location:mhs_loker.php');
        }
    }
    
?>