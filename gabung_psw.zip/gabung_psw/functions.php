<?php
function pdo_connect_mysql() {
    $DATABASE_HOST = 'localhost';
    $DATABASE_USER = 'root';
    $DATABASE_PASS = '';
    $DATABASE_NAME = 'db_lokerku';
    try {
    	return new PDO('mysql:host=' . $DATABASE_HOST . ';dbname=' . $DATABASE_NAME . ';charset=utf8', $DATABASE_USER, $DATABASE_PASS);
    } catch (PDOException $exception) {
    	// If there is an error with the connection, stop the script and display the error.
    	exit('Failed to connect to database!');
    }
}

function template_header($title) {
echo <<<EOT
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <!--====== Title ======-->
    <title>LokerKu - Loker</title>
    
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/img/logo.png" type="image/png">
        
    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="assets/css/animate.css">
        
    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="assets/css/slick.css">
        
    <!--====== Line Icons CSS ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">
        
    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!--====== Default CSS ======-->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<!--====== FONT ======-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@600&family=Comfortaa:wght@600&family=Lato:wght@700&family=Open+Sans:ital,wght@0,700;1,600&family=Rammetto+One&family=Rokkitt:wght@400;500;600&family=Sriracha&display=swap" rel="stylesheet">
    <link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">

    <style>
       .nav-item a{
            text-decoration: none;
        }

        .form{
            width: 700px;
            height: 450px;
        }
    </style>

</head>

<body class="d-flex flex-column min-vh-100">

    <!--====== HEADER PART START ======-->
    <section class="header_area">
        <div class="header_navbar" style="background-color:rgb(96, 125, 96);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            
                            <a class="navbar-brand" href="">
                                <div class="d-flex flex-row">
                                    <img class="p-2" src="assets/img/logo.png" height="90" width="80" alt="Logo">
                                    <p class="p-2 m-1 align-self-end judul-nav">Loker Ku</p>
                                </div>
                                
                            </a>
                            <button class="navbar-toggler nav-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ml-auto">
                                    <li class="nav-item">
                                        <a href="mhs_beranda.php">Beranda</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#chat">Chat</a>
                                    </li>
                                    <li class="nav-item  active">
                                        <a href="">Loker</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#logout">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  											    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  												<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
											</svg>
                                        </a>
                                    </li>
                                </ul>
                            </div> <!-- navbar collapse -->
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div>
        </div> <!-- header navbar -->
	</section>
EOT;
}
function template_footer() {
echo <<<EOT
<section id="footer" class="footer_area mt-auto" style="background-color:#58685A;">
<!-- <hr class="footer_hr" size="5"> -->
<div class="footer_copyright">
	<div class="container">
		<div class="copyright text-center">
			<p>Sistem Informasi Keasramaan copyright @ 2022 Institut Teknologi Del.<a href="" rel="nofollow"> All right reserved </a></p>
		</div> <!-- copyright -->
	</div> <!-- contact form -->
</div> <!-- footer copyright -->
</section>
EOT;
}
?>

