<?php
include 'functions.php';
$pdo = pdo_connect_mysql();
$msg = '';

if (isset($_GET['nim'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $nim = isset($_POST['nim']) ? $_POST['nim'] : NULL;
        $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
        $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
        $passLoker = isset($_POST['passLoker']) ? $_POST['passLoker'] : '';
        
        // Update the record
        $stmt = $pdo->prepare('UPDATE tambahmahasiswa SET nim = ?, nama = ?, gender = ?, passLoker = ? WHERE nim = ?');
        $stmt->execute([$nim, $nama, $gender, $passLoker, $_GET['nim']]);
        $msg = 'Updated Successfully!';
    }
    // Get the contact from the contacts table
    $stmt = $pdo->prepare('SELECT * FROM tambahmahasiswa WHERE nim = ?');
    $stmt->execute([$_GET['nim']]);
    $contact = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$contact) {
        exit('College doesn\'t exist with that NIM!');
    }
} else {
    //exit('No NIM specified!');
}
?>



<?=template_header('Read')?>

<div class="content update">
	<h2>Add Mahasiswa</h2>
    <form action="create.php" method="post">
        <label for="nim">NIM</label>
        <label for="nama">Nama</label>
        <input type="text" name="id" value="auto" id="id">
        <input type="text" name="nama" id="nama">
        <label for="gender">gender</label>
        <label for="passLoker">Password Loker</label>
        <input type="text" name="gender" id="gender">
        <input type="text" name="passLoker" id="passLoker">
        <input type="submit" value="Update">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>

<?=template_footer()?>