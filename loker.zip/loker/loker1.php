<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <!--====== Title ======-->
    <title>Lokerku</title>
    
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/logo.png" type="image/png">
        
    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="assets/css/animate.css">
        
    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="assets/css/slick.css">
        
    <!--====== Line Icons CSS ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">
        
    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!--====== Default CSS ======-->
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<!--====== FONT ======-->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bitter:wght@600&family=Comfortaa:wght@600&family=Lato:wght@700&family=Open+Sans:ital,wght@0,700;1,600&family=Rammetto+One&family=Rokkitt:wght@400;500;600&family=Sriracha&display=swap" rel="stylesheet">
    
    <style>
       .nav-item a{
            text-decoration: none;
        }
    </style>

</head>

<body>

    <!--====== HEADER PART START ======-->
    <section class="header_area">
        <div class="header_navbar" style="background-color:rgb(96, 125, 96);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg">
                            
                            <a class="navbar-brand" href="">
                                <div class="d-flex flex-row">
                                    <img class="p-2" src="assets/img/logo_1.png" height="90" width="80" alt="Logo">
                                    <p class="p-2 m-1 align-self-end judul-nav">Loker Ku</p>
                                </div>
                                
                            </a>
                            <button class="navbar-toggler nav-button" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ml-auto">
                                    <li class="nav-item">
                                        <a href="#beranda">Beranda</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#chat">Chat</a>
                                    </li>
                                    <li class="nav-item active">
                                        <a href="">Loker</a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="#logout">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-circle" viewBox="0 0 16 16">
  											    <path d="M11 6a3 3 0 1 1-6 0 3 3 0 0 1 6 0z"/>
  												<path fill-rule="evenodd" d="M0 8a8 8 0 1 1 16 0A8 8 0 0 1 0 8zm8-7a7 7 0 0 0-5.468 11.37C3.242 11.226 4.805 10 8 10s4.757 1.225 5.468 2.37A7 7 0 0 0 8 1z"/>
											</svg>
                                        </a>
                                    </li>
                                </ul>
                            </div> <!-- navbar collapse -->
                        </nav> <!-- navbar -->
                    </div>
                </div> <!-- row -->
            </div>
        </div> <!-- header navbar -->
	</section>

    <!--====== HEADER PART ENDS ======-->
    

    <!--====== LOKER PART START ======-->
    <section>
        <div class="loker-konten container" style="padding-top:30px;">
            <a class="back" href="infoLoker.php">Kembali ></a>
            <div class="d-flex justify-content-between" style="padding:20px 10px;">
                <p class="noLoker">Loker 1</p>
                <p class="kodeLoker">yo_bro</p>
            </div>
            <div>
                <table class="mahasiswa">
                    <tr>
                        <td>Nama</td>
                        <td>:</td>
                        <td>Ignatius Simamora</td>
                    </tr>
                    <tr>
                        <td>NIM</td>
                        <td>:</td>
                        <td>11421019</td>
                    </tr>
                </table><hr>
            </div>
            <div>
                <table border="1" class="table table-hover">
                    <thead>
                        <tr style="background-color:#A0B9A3;">
                            <th scope="col">Jenis Barang</th>
                            <th scope="col">Waktu Penyimpanan</th>
                            <th scope="col">Waktu Pengambilan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Sepatu Hitam Adidas</td>
                            <td>Senin, 31 Januari 2022 / 11.00</td>
                            <td>Selasa, 01 Februari 2022 / 06.45</td>
                        </tr>
                        <tr>
                            <td>Rinso Molto 770 gr</td>
                            <td>Senin, 31 Januari 2022 / 11.00</td>
                            <td>Minggu, 27 Februari 2022 / 11.00</td>
                        </tr>
                        <tr>
                            <td>Sandal Tali Hijau Eiger</td>
                            <td>Senin, 31 Januari 2022 / 11.00</td>
                            <td>Senin, 31 Januari 2022 / 18.00</td>
                        </tr>
                        <tr>
                            <td>Sandal Tali Hijau Eiger</td>
                            <td>Senin, 31 Januari 2022 / 22.00</td>
                            <td>-</td>
                        </tr>
                    </tbody>
                    
                </table>
            </div>
            <div class="tombol d-flex justify-content-between" style="padding:20px 10px;">
                <a href="#">
                    <button type="button">Buat Laporan</button>
                </a>
                <a href="#">
                    <button type="button">Hapus Alokasi</button>
                </a>
            </div>
        </div>    
    </section>

    <!--====== LOKER PART END ======-->

    
    <!--====== FOOTER PART START ======-->

    <section id="footer" class="footer_area">
        <hr class="footer_hr" size="5">
        <div class="footer_copyright">
            <div class="container">
                <div class="copyright text-center">
                    <p>Sistem Informasi Keasramaan copyright @ 2022 Institut Teknologi Del.<a href="" rel="nofollow"> All right reserved </a></p>
                </div> <!-- copyright -->
            </div> <!-- contact form -->
        </div> <!-- footer copyright -->
    </section>

    <!-- <section id="footer" class="footer_area">
	<hr class="footer_hr" width="100%" size="5" style="background-color:#607d60;">
    <footer id="kontak" class="jumbotron text-center" style="margin-bottom:0">
        <p>Sistem Informasi Keasramaan copyright @ 2022 Institut Teknologi Del. All right reserved</p>
    </footer>
    </section> -->

    <!--====== FOOTER PART ENDS ======-->
    
    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="lni lni-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->
    
    <!--====== PART START ======-->


    <!--====== PART ENDS ======-->




    <!--====== Jquery js ======-->
    <script src="assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="assets/js/vendor/modernizr-3.7.1.min.js"></script>
    
    <!--====== Bootstrap js ======-->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>
    
    
    <!--====== Scrolling Nav js ======-->
    <script src="assets/js/jquery.easing.min.js"></script>
    <script src="assets/js/scrolling-nav.js"></script>
    
    <!--====== WOW js ======-->
    <script src="assets/js/wow.min.js"></script>
    
    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>
    
</body>

</html>

